# Monitoraggio processi


![Language](https://img.shields.io/badge/Spellcheck-Pass-green?style=flat)
![Platform](https://img.shields.io/badge/OS%20platform%20supported-Windows-blue?style=flat)
![Language](https://img.shields.io/badge/Language-Python-yellowgreen?style=flat)
![Testing](https://img.shields.io/badge/PEP8%20CheckOnline-Passing-green)
![Testing](https://img.shields.io/badge/Test-Pass-green)

## Descrizione

In questo programma si usa la libreria psutil per salvare sui files ps.csv, ps.xml e ps.db il nome dei processi, lo stato e la loro data di creazione.

## Requisiti

python, tqdm

## Esecuzione

Andare nella cartella package del deploy ed eseguire il file .bat

## Tags

python, windows, psutil

#### [01.01] 2022-12-20

***

## Author

Serafini Michele